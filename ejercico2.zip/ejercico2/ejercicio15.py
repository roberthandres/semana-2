for i in range(5, 51, 5):
    print(i)

# o con validación de múltiplo:
# for i in range(5, 51):
#     if i % 5 == 0:
#         print(i)