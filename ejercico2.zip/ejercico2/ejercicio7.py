for i in range(10, 0, -1):
    print(i)
print("¡Tiempo terminado!")