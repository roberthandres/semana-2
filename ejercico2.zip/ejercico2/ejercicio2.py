CLAVE = "1234"
while True:
    clave = input("Ingrese clave: ")
    if clave == CLAVE:
        print("Bienvenido")
        break
    else:
        print("Clave incorrecta")